void Borrow();
void Return();
void SearchMenu();
void Search();
void Find(char information[40],int ID);
void Browse();
