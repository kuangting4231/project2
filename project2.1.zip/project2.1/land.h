void newAcount();
int  matchAccount(int IDnum,char password1[20],char IDjudge);
void land();
