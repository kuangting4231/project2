#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "stack.h"
#include "link.h"
#include "student.h"
#include "StudentMenu.h"
#include "landMenu.h"
#define N1 sizeof(struct studentbook)



void Borrow()//borrow book
{
    FILE *fp;
    Book *book,*p;
    char data[20]={'\0'},rdata[20]="none";
    int ID;
    system("cls");
	printf("\n\t\t\t\tPlease enter the bookID you borrowed:");
	scanf("%d",&ID);
    p=link("none");
    book=p;
    while(book!=NULL){
       if(ID==book->bookNumber){
        if(book->num >0)
            book->num--;
        else{
         printf("\n\n\t\tThe inventory is 0!!! Cannot be lent");
	     getch();
	     student();
        }
       }
       book=book->next;
    }
    saveBook(book);
    if ((fp=fopen("student-book.txt","r"))==NULL)
	{
      fp=fopen("student-book.txt","w");
      fclose(fp);
    }
	fp=fopen("student-book.txt","a");

	printf("\n\t\t\t\tPlease enter the borrow data:");
	scanf("%s",data);
	fprintf(fp,"%d %d %s %s\n",ACCOUNT,ID,data,rdata);
	fclose(fp);
	printf("\n\t\t\t   Successful borrowing,Press any key to continue!");
	getch();
	student();
return;
}
void Return()//return book
{
FILE *fp;
    Book *q,*q1;
    SB *head=NULL;
    SB *p,*p1,*p2;
    int sum,i,j=0;
	int account=0,ID=0;
    char  btime[20]={'\0'},rtime[20]={'\0'};
    int ID1=0,t=0;
    char data[20]={'\0'};
    system("cls");
	printf("\n\t\t\t\tPlease enter the bookID:");
	scanf("%d",&ID1);
	printf("\n\t\t\t\tPlease enter the return data");
	scanf("%s",data);


    if ((fp=fopen("student-book.txt","r"))==NULL)
    {
         printf("No information of readers!!!!");
         getch();
         student();
    }

    for (sum=0;!feof(fp);sum++)
        fscanf(fp,"%d %d %s %s ",&account,&ID,btime,rtime);
    fclose( fp);

    fp=fopen("student-book.txt","r");
    for(i=1;i<sum;i++){
        fscanf(fp,"%d %d %s %s ",&account,&ID,btime,rtime);
            j++;
            if(j==1){
                p=p1=(SB*)malloc(N1);
                head=p;
            }
            else{
                p1->next=p;
                p1=p;
                p=(SB*)malloc(N1);
            }
            if(account==ACCOUNT&&ID==ID1){
                strcpy(rtime,data);
                t++;
            }

            strcpy(p->btime,btime);
            strcpy(p->rtime,rtime);
            p->account=account;
            p->ID=ID;
    }
    if(j==0)
        head=NULL;
    else{
        p1->next=p;
        p->next=NULL;
        }
    p2=head;
    fclose(fp);
    saveSB(p2);

    if(t>0){
        q=link("none");
        q1=q;
        while(q1!=NULL){
            if(ID==q1->bookNumber){
                q1->num++;
            }
            q1=q1->next;
        }
        saveBook(q1);
        printf("\n\t\t\t\tSuccessful returning!!!");
    }
	else{
        printf("\n\t\t\tThere is no borrowing record of this book or this people!!!!\n ");

	}
        printf("\n\t\t\tPress any key to return to upper level\n");
        getch();
        student();
}
void SearchMenu()//print menu of search
{
    system ("cls");
printf("\n\n\t\t\t\t ***********************************************************\n\n");
printf("\t\t\t\t                 | 1. ID query             |               \n\n");
printf("\t\t\t\t                 | 2. Name query           |               \n\n");
printf("\t\t\t\t                 | 3. Author query         |               \n\n");
printf("\t\t\t\t                 | 4. Type query           |               \n\n");
printf("\t\t\t\t                 | 5. Publisher query      |               \n\n");
printf("\t\t\t\t                 | 6. Publish time query   |               \n\n");
printf("\t\t\t\t***********************************************************\n");
return ;

}
void Search()//search book
{
    SearchMenu();
    char t;
    char information[40]={'\0'};
    int ID=0;
    t=getch();
    system("cls");

    if(t=='1'){
        printf("\n\n\t\t\tPlease enter the BookID you want to search:");
        scanf("%d",&ID);
    }
    if(t=='2'){
        printf("\n\n\t\t\tPlease enter the Book name you want to search:");
        scanf("%s",information);
    }
    if(t=='3'){
        printf("\n\n\t\t\tPlease enter the Book author you want to search:");
        scanf("%s",information);
    }
    if(t=='4'){
        printf("\n\n\t\t\tPlease enter the Book type you want to search:");
        scanf("%s",information);
    }
    if(t=='5'){
        printf("\n\n\t\t\tPlease enter the Book publisher you want to search:");
        scanf("%s",information);
    }
    if(t=='6'){
        printf("\n\n\t\t\tPlease enter the Book publish time you want to search:");
        scanf("%s",information);
    }
    system("cls");
    printf("\n  ***********************************************Book Overview******************************************************");
	printf("\n  BookID   name                author         type         publisher              publishtime   price  num  ");
	printf("\n  -----------------------------------------------------------------------------------------------------------------");

    Find(information,ID);
    printf("\n\t\t\tpress any key to return to upper level\n");
    getch();
    student();

}

void Find(char information[40],int ID)//search function
{
    Book *p,*q;
    q=link("none");
    p=q;

    while(p!=NULL){
        if(p!=NULL){
            if(p->bookNumber==ID||strcmp(p->name,information)==0||strcmp(p->name,information)==0||strcmp(p->name,information)==0||strcmp(p->name,information)==0||strcmp(p->name,information)==0||strcmp(p->author,information)==0||strcmp(p->type,information)==0||strcmp(p->publisher,information)==0||strcmp(p->publishtime,information)==0)
        printf("\n  %-9d%-20s%-15s%-13s%-23s%-14s%-7.2f%-5d",p->bookNumber,p->name,p->author,p->type,p->publisher,p->publishtime,p->price,p->num);
        p=p->next;
        }

    }

}
void Browse()//browse returning information
{
    system("cls");
    FILE *fp;
    int account=0,ID=0;
    int sum,i;
    char btime[20]={'\0'},rtime[20]={'\0'};
    fp=fopen("student-book.txt","r");
    if (fp==NULL){
        printf("The file is not exist!Press any key to continue");
        getch();
        student();
    }
    for(sum=0;!feof(fp);sum++){
        fscanf(fp,"%d %d %s %s",&account,&ID,btime,rtime);
    }
    fclose(fp);
    fp=fopen("student-book.txt","r");
    printf("\n\t\t\t*************************Browse Overview*****************************");
    printf("\n\t\t\t   account(student)    BookID         borrow time       return time  ");
    for(i=1;i<sum;i++){
        fscanf(fp,"%d %d %s %s",&account,&ID,btime,rtime);
        if(account==ACCOUNT)
            printf("\n\t\t\t   %-12d        %-10d     %-10s        %-10s",account,ID,btime,rtime);
    }
    fclose(fp);
    printf("\n\n\t\t\t\tPress any key to continue");
    getch();
    student();

}
