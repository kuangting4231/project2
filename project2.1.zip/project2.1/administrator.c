#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "stack.h"
#include "link.h"
#include "administrator.h"
#include "administratorMenu.h"




void addBook()//add book
{
    FILE*fp;
	char t;
	int bookNumber=0,num=0;
    float price=0;
    char  name[40]={'\0'},author[40]={'\0'},type[40]={'\0'},pub[40]={'\0'},pubtime[40]={'\0'};

    system ("cls");

    if ((fp=fopen("book.txt","r"))==NULL)
	{
      fp=fopen("book.txt","w");
      fclose(fp);
    }
    fp=fopen("book.txt","w");

    while(1){

    printf("\n\n\t\t\t\t     Please enter the book number(ID)(4 number): ");
	scanf("%d",&bookNumber);
	printf("\n\t\t\t\t     Please enter the number: ");
    scanf("%d",&num);
	printf("\n\t\t\t\t     Please enter the book price: ");
    scanf("%f",&price);
    printf("\n\t\t\t\t     Please enter the book name: ");
    scanf("%s",name);
	printf("\n\t\t\t\t     Please enter the book publisher: ");
    scanf("%s",pub);
	printf("\n\t\t\t\t     Please enter the book publish time: ");
    scanf("%s",pubtime);
	printf("\n\t\t\t\t     Please enter the book author: ");
    scanf("%s",author);
	printf("\n\t\t\t\t     Please enter the book type: ");
    scanf("%s",type);

    fprintf(fp,"%d %d %s %s %s %s %s %.2f\n",bookNumber,num,name,pub,pubtime,author,type,price);
    fclose(fp);
    system("cls");
    printf("\n\n\n\t\t\t\t\t-----------------------------------------");
    printf("\n\t\t\t\t\t|                                       |");
    printf("\n\t\t\t\t\t| Save succeeded, whether to continue?  |");
    printf("\n\t\t\t\t\t|       1.yes             2.no          |");
    printf("\n\t\t\t\t\t|                                       |");
    printf("\n\t\t\t\t\t-----------------------------------------");
    t=getch();
    if(t=='1')
        system("cls");
    if(t=='2'){
        administrator();
        break;
    }
    }
return ;
}


void deleteBook()//delete book
{
    Book *p;
    char name[40]={'\0'};
    char t;
    while(1){
    printf("\n\n\t\t\t\tPlease enter the book name you want to delete");
    scanf("%s",name);
    p=link(name);
    saveBook(p);
    system ("cls");
    printf("\n\n\n\t\t\t\t\t-----------------------------------------");
    printf("\n\t\t\t\t\t|                                        |");
    printf("\n\t\t\t\t\t| Delete succeeded, whether to continue? |");
    printf("\n\t\t\t\t\t|        1.yes             2.no          |");
    printf("\n\t\t\t\t\t|                                        |");
    printf("\n\t\t\t\t\t------------------------------------------");
    t=getch();
    if(t=='1')
    system("cls");
    if(t=='2'){
        administrator();
        break;
    }
    }
}
void bookOV()//overview the information of book
{
    Book *p, *book;
    book=link("none");
    p=book;
    system("cls");
    if (p==NULL){
        printf("There is no information in the file");
        getch();
        administrator();
    }
    printf("\n  ***********************************************Book Overview******************************************************");
	printf("\n  BookID   name                author         type         publisher              publishtime   price  num  ");
	printf("\n  -----------------------------------------------------------------------------------------------------------------");
    for (;p!=NULL;){
        printf("\n  %-9d%-20s%-15s%-13s%-23s%-14s%-7.2f%-5d",p->bookNumber,p->name,p->author,p->type,p->publisher,p->publishtime,p->price,p->num);
        p=p->next;
    }
    printf("\n\n\n\t\t\t\t\tPress any key to continue");
    getch();
    administrator();
}
void studentOV()//overview the information of student
{
    system("cls");
    FILE *fp;
    int account,i,sum;
    char password[20]={'\0'},name[20]={'\0'};
    fp=fopen("student.txt","r");
    if (fp==NULL){
        printf("The file is not exist");
        getch();
        administrator();
    }
    for(sum=0;!feof(fp);sum++){
        fscanf(fp,"%s %d %s",name,&account,password);
    }
    fclose(fp);
    printf("\n\t\t\t**********************Student Overview********************************");
    printf("\n\t\t\t      name              accountName                 password          ");
    fp=fopen("student.txt","r");
    for(i=1;i<sum;i++){
        fscanf(fp,"%s %d %s",name,&account,password);
        printf("\n\t\t\t      %-18s%-28d%-18s",name,account,password);
    }
    fclose(fp);
    printf("\n\n\t\t\t\t\tPress any key to continue");
    getch();
    administrator();
}
