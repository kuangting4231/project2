#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "student.h"
#include "StudentMenu.h"
#include "landMenu.h"


void studentMenu(){
system ("cls");
printf("\n\n\t\t\t\t ***********************************************************\n\n");
printf("\t\t\t\t                 | 1. Borrow book          |               \n\n");
printf("\t\t\t\t                 | 2. Return book          |               \n\n");
printf("\t\t\t\t                 | 3. Search book          |               \n\n");
printf("\t\t\t\t                 | 4. Browse book returns  |               \n\n");
printf("\t\t\t\t                 | 5. Back to main menu    |               \n\n");
printf("\t\t\t\t                 | 6. Log out              |               \n\n");
printf("\t\t\t\t***********************************************************\n");
return ;
}

void student(){
    studentMenu();
    char t;
    t=getch();
    switch(t){
        case '1':Borrow();break;
        case '2':Return();break;
        case '3':Search();break;
        case '4':Browse();break;
        case '5':main();break;
        case '6':
        system("cls");
  	    exit(0);
	    break;
        default :break;
    }
return ;
}

