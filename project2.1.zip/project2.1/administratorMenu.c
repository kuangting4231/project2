#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "administrator.h"
#include "administratorMenu.h"
#include "landMenu.h"

void administratMenu(){
system ("cls");
printf("\n\n\t\t\t\t ******************************************************\n\n");
printf("\t\t\t\t                 | 1. Add book          |             \n\n");
printf("\t\t\t\t                 | 2. Delete book       |             \n\n");
printf("\t\t\t\t                 | 3. Book overview     |             \n\n");
printf("\t\t\t\t                 | 4. Student overview  |             \n\n");
printf("\t\t\t\t                 | 5. Back to main menu |             \n\n");
printf("\t\t\t\t                 | 6. Log out           |             \n\n");
printf("\t\t\t\t******************************************************\n");
return ;
}


void administrator(){
    administratMenu();
    char t;
    t=getch();
    switch(t){
        case '1':addBook();break;
        case '2':deleteBook();break;
        case '3':bookOV();break;
        case '4':studentOV();break;
        case '5':main();break;
        case '6':
        system("cls");
  	    exit(0);
	    break;
        default : break;
    }
return ;
}
