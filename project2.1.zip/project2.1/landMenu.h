void mainmenu();
void main();
int ACCOUNT;
