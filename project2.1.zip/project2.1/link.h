Book *link(char cname[20]);
void saveBook(Book *p);
void saveSB(SB *p);



