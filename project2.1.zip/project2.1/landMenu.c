#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "land.h"
#include "landMenu.h"

void mainmenu()//print the menu of landing
{
    system("cls");
printf("\n\n\t\t\t\t        Welcome to the book management system     \n\n");
printf("\t\t\t\t********************************************** ****\n\n");
printf("\t\t\t\t                 1.Landing system             \n\n");
printf("\t\t\t\t                 2.New account                \n\n");
printf("\t\t\t\t                 3.Exit system                \n\n");
printf("\t\t\t\t**************************************************\n");
return ;
}
void main()
{
	char t;
	mainmenu();
	t=getch();
	switch(t)
  {
	  case '1':
	    land();
	    break;
	  case '2':
	  	newAcount();
	  	break;
	  case '3':
	  	system("cls");
  	    exit(0);
	    break;
      default :break;
  }
return ;
}
